"use strict";

module.exports = {

    mysqlConfig: {
        host: "localhost",
        user: "root",
        password: "",
        database: "bd_practvoluntaria"
    },

    port: 3000
}